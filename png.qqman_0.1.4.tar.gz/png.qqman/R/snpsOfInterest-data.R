#' @name snpsOfInterest
#' @title snpsOfInterest
#' @description Example SNPs of interest from simulated \code{gwasResults} data.
#' @docType data
NULL