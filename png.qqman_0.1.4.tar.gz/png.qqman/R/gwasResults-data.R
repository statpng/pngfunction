#' @name gwasResults
#' @title Simulated GWAS results
#' @description Simulated GWAS results as obtained from \code{plink --assoc}.
#' @docType data
NULL